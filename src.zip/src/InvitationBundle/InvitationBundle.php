<?php

namespace InvitationBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class InvitationBundle extends Bundle
{
}
