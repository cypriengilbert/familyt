<?php

namespace AccountingBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class AccountingBundle extends Bundle
{
}
