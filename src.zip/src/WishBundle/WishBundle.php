<?php

namespace WishBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class WishBundle extends Bundle
{
}
